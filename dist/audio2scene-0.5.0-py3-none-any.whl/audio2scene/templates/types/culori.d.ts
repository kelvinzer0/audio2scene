declare module "culori";
